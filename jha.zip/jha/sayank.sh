git pull 
cd ..
cp -r sayankb lab
echo "working pull complete"
